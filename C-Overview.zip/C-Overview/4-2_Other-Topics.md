### Implementation-Defined Behavior
- The C standard deliberately leaves parts of the language unspecified, leaving the compiler to 'implement' these unspecified parts. This leads to some differences from one machine to another. It is best to avoid implementation-defined behavior, but it is sometimes not possible if we want to build the fastest possible programs for specific hardware.

### Undefined Behavior
- When have complex operation using all types of operators, we risk having undefined behavior. Undefined behavior might cause the program to act erratically, produce different output from a machine to another, or completely crash. All cases of undefined behavior should be avoided at all cost.