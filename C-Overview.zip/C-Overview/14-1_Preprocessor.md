# Preprocessor in C

### How does the preprocessor operate ?

### Preprocessing Directives

### Macro Definitions

### Conditional Compilation

### Miscellaneous Directives
