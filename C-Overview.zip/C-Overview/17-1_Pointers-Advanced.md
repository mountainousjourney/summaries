# Advanced Uses of Pointers

### Dynamic Storage Allocation

### Dynamically Allocated Strings

### Dynamically Allocated Arrays

### Deallocating Storage

### Linked Lists

### Pointers to Pointers

### Pointers to Functions

### Restricted Pointers (standard C99)

### Flexible Array Members (standard C99)
