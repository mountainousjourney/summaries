# Structures, Unions, and Enumerations

### Structure Variables

### Structure Types

### Nested Arrays and Structures

### Unions

### Enumerations
