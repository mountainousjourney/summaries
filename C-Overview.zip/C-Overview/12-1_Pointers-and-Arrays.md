# Pointers and Arrays

### Pointer Arithmetic

### Using Pointers for Array Processing

### Using an Array Name as a Pointer

### Pointers and Multidimensional Arrays

### Pointers and Variable-Length Arrays (C99 standard)