# Pointers in C

### Pointer Variables in C

### Address and Indirection Operators

### Pointer Assignment

### Pointers as Arguments

### Pointers as Return Values
