# Strings

### Strings Literals

### String Variables

### Reading and Writing Strings

### Accesing the Characters in a String

### Using the C String Library

### String Idioms

### Arrays of Strings
