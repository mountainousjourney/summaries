### Why should I use Lint ?
- Lint checks C programs for potential errors not picked up by the compiler, like unused variables, unreachable code or nonportable code.

-  Most compilers can do a more thorough job of error-checking by specifying a 'warning level' (i.e. higher warning levels means more thorough checks).

- Apart from lint/debuggers, you can also use tools like 'bounds-checkers', which checks array subscripts/indices, and 'leak-finders', which helps locate memory leaks or dynamically allocated blocks of memory which are never deallocated.