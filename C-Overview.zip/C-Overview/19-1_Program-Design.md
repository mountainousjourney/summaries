# C Program Design

### Modules

### Information Hiding

### Abstract Data Types

### Design Issues for Abstract Data Types
