# Functions in C

### Defining and Calling Functions in C

### Function Definitions

### Function Calls

### Function Declarations in C

### Function Arguments

### Argument Conversions

### Array Arguments

### Variable-Length Array Parameters (Standard C99)

### Using *static* in Array Parameter Declarations

### Compound Literals

### The return statement

### Program Termination

### Using the *exit* function