# Arrays in C
- Arrays in C are an aggregate of variables of a certain type.
### One-Dimensional Arrays in C
- An array in C can be declared and initialized in the same line : ```int a[2] = {3,6};```. If the initializer is shorter than the array, the rest of the elements are given the value of zero.
- The standard *C99* introduced designated initializers : ```int a[5] = {[1]=3, [3]=5};```
- We can use the ```sizeof``` operator to verify the size of an array : ```sizeof(a)/sizeof(a[0])```.

### Multidimensional Arrays in C
- Multidimensional Arrays can be declared and initialized in C using the following method : ```int a[2][2] = {{4,5},{2,3}}```

### Constant Arrays
- One-dimensional / Multidimensional array can be made constant in C. This means that they are not able to be modified in the code, and any attempt will be detected by the compiler.
- Example in code : ```const int a[2][2] = {{4,5},{2,3}}```

### Variable-Length Arrays in C (C99 Standard)
- Variable-Length Arrays have been introduced in the standard *C99*. They cannot take an initializer value.
- Example in code :
```c
int n;
....
// We take n as an input from the user

int a[n];
```