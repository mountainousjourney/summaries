# Expressions in C

### Expression Statements
- Expressions in C can be used as standalone statements.
- Example : ```i--;```

### Arithmetic Operators
- Arithmetic operators are quite straightforward : ```+, -, *, /, %```, which represent addition, substraction, multiplication, division, and remainder respectively.

### Assignment Operators
- The assignment operator is ```=``` in C.
- Several assignments can be chained together : ``` i = j = k = 0```, although it might lead to issues, especially if the variables being assigned are of different type.
- Example of a compound assignment : ```i = i+ 2```.

### Increment and Decrement Operators
- Considering that two of the common operations on a variable are incrementing and decrementing, it is possible to perform these tasks using specific operators.
- Example of Increment Operator : ```i += 1```
- Example of Decrement Operator : ```i -= 1```
- It is also important to know the differencebetween the **postfix** and the **prefix** operators (```i++/i--``` vs ```++i/--i```).
- There are also variant which allow us to multiply or divide values by a certain constant/variable : ```i *= 1``` or ```i /= 1```

### Expression Evaluation
Here's a complete table to understand the order of precedence with all operators in C :
| Precedence | Operator Symbol |
 -----------   ----------------
|1|(postfix) ++, --|
|2|(prefix) ++, --|
|3|*, /, %|
|4|+, -|
|5|=, *=, /=, %=, +=, -=|